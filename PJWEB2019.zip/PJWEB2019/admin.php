<?php
session_start();
if(isset($_POST['submit'])) {
	if(($_POST['username'])&&($_POST['password'])){
		if(($_POST['username']=="admin")&&($_POST['password']=="admin")) {

			$_SESSION['username']=$_POST['username'];
			header('Location:admin1.php');
		}
		else{
			echo 'Acces non autorise';
		}
	}
	else{
		echo 'Champs vides: Veuillez remplir';
	}
}
?>

<body style="background:#A9F5E1;"></body>
<h1 align="center"><u><big> Page Administrateur </big></u> </h1>
<form align="center" action="" method="POST">
<h2>Pseudo :</h2>
<input placeholder="Entrez votre pseudo" type="text" name="username"/><br/><br/>
<h2>Mot de passe :</h2>
<input placeholder="Entrez votre mot de passe"type="password" name="password"/><br/></br/>
<input type="submit" name="submit"/><br/><br/>
</form>
</div

