<?php
require_once("header.php");
session_start();
?>
<h1 align="center"><u>Bienvenue à l'administrateur</u></h1>
<p align="right"><a href="?logout">Déconnexion</a></p>
<p align="center"><a href="?article=add">Ajouter un item</a></p>
<p align="center"><a href="?article=delete">Supprimer un item</a></p>
<p align="center"><a href="?vendeur=add">Ajouter un vendeur</a></p>
<p align="center"><a href="?vendeur=delete">Supprimer un vendeur</a></p>
<body style="background:#A9F5E1;"></body>

<?php
if (isset ($_GET['logout'])){ 
	session_destroy(); 
	header('Location: index1.php');
}
?>
<?php 

if(isset($_SESSION['username']))
{
	if(isset($_GET['vendeur']))
	{
		if($_GET['vendeur']=='add')
		{
			if(isset($_POST['submit']))
			{
				
				if(($_POST['email'])&&($_POST['pseudo'])&&($_POST['nom']))
				{
					$email=$_POST['email'];
					$pseudo=$_POST['pseudo'];
					$nom=$_POST['nom'];


					$database = "ece_amazon";
					$db_handle = mysqli_connect('localhost', 'root', '' );
					$db_found = mysqli_select_db($db_handle, $database );
					if ($db_found) 
					{
						$SQL = "INSERT INTO vendeur( email, pseudo, nom)  VALUES ('$email', '$pseudo', '$nom')";
     					$result = mysqli_query($db_handle, $SQL);
     					mysqli_close($db_handle);
    					echo "<<<<<<<Vous avez ajouter un vendeur>>>>>>>";
					}
					else 
					{
    					echo "Database NOT Found ";
					}
				}
				else
				{
					echo "Champs vides: Veuillez remplir";
				}	
			}
		?>
			<body style="background:#A9F5E1;"></body>
			<h3><u>Remplir les champs pour ajouter un vendeur</u><h3>
			<form align="center" action="" method="POST">
			<h3><u>Email ECE :</u></h3><input placeholder="Entrez un mail" type="text" name="email"/>
			<h3><u>Pseudo :</u></h3><input placeholder="Entrez un pseudo" type="text" name="pseudo"/>
			<h3><u>Nom :</u></h3><input placeholder="Entrez un nom" type="text" name="nom"/><br/><br/>
			<input type="submit" name="submit">
			</form>
		<?php
		
		}
		else if($_GET['vendeur']=='delete')
		{
			echo "<br><br>";
			echo 'Voici les vendeurs autorisés à vendre: ';
			$database = "ece_amazon";
			$db_handle = mysqli_connect('localhost', 'root', '' );
			$db_found = mysqli_select_db($db_handle, $database );
			if($db_found)
			{
				$SQL2="SELECT * FROM vendeur";
			    $result = mysqli_query($db_handle, $SQL2);
     			mysqli_close($db_handle);
			}
			echo "<br>";
    		
    		while ($db_field = mysqli_fetch_assoc($result))
    		{
    			echo "<br>";
                echo $db_field['nom'];
                echo "<br>";
            
        	}
        	if(isset($_POST['submit']))
			{
				
				if($_POST['nom'])
				{
					$nom=$_POST['nom'];
					$database = "ece_amazon";
					$db_handle = mysqli_connect('localhost', 'root', '' );
					$db_found = mysqli_select_db($db_handle, $database );
					if ($db_found) 
					{
						$SQL = "DELETE FROM vendeur WHERE nom='$nom'";
     					$result = mysqli_query($db_handle, $SQL);
     					mysqli_close($db_handle);

					}
					else 
					{
    					echo "Database NOT Found ";
					}
				}
		
			}
			?>
			<body style="background:#A9F5E1;"></body>
			<form align="center"action="" method="POST">
			<h3><b><u>Entrez le nom du vendeur que vous voulez supprimer</u></b></h3>
			<h3><u>Nom</u>:</h3><input placeholder="Entrez le nom" type="text" name="nom"/>
			<input type="submit" name="submit">
		    </form>
		    <?php
        }		

	}

	if(isset($_GET['article']))
	{
		if($_GET['article']=='add')
		{
			if(isset($_POST['submit']))
			{
				
				if(($_POST['Nom'])&&($_POST['Description'])&&($_POST['Prix'])&&($_POST['Categorie']))
				{
					$Nom=$_POST['Nom'];
					$Description=$_POST['Description'];
					$Prix=$_POST['Prix'];
					$Categorie=$_POST['Categorie'];

					$database = "ece_amazon";
					$db_handle = mysqli_connect('localhost', 'root', '' );
					$db_found = mysqli_select_db($db_handle, $database );
					if ($db_found) 
					{
						$SQL = "INSERT INTO item( Nom, Description, Prix, Categorie)  VALUES ('$Nom', '$Description', '$Prix', '$Categorie')";
     					$result = mysqli_query($db_handle, $SQL);
     					mysqli_close($db_handle);
    					echo "Vous avez ajouter un item au marché";
					}
					else 
					{
    					echo "Database NOT Found ";
					}
				}
				else
				{
					echo "Champs vides: Veuillez remplir";
				}	
			}
		?>
			<body style="background:#A9F5E1;"></body>
			<h2><u>Remplir les champs pour ajouter votre item</u><h2>
			<form align="center" action="" method="POST" enctype="multipart/form-data">
			<h3><u>Nom :</u></h3><input placeholder="Entrez un nom" type="text" name="Nom"/>
			<h3><u>Description :</u></h3><textarea placeholder="Entrez une description" name="Description"></textarea> 
			<h3><u>Prix :</u></h3><input placeholder="Entrez un prix" type="text" name="Prix"/>
			<h3><u>Image(A venir prochainement..) :</u></h3><input type="file" name="img"/><input type="hidden" name="MAX_FILE_SIZE" value="100000">

			<h3><u>Categorie :</u></h3>
			<select name="Categorie">
				<option value="Livres">Livres</option>
				<option value="Musique">Musique</option>
				<option value="Vêtemets">Vêtements</option>
				<option value="Sport&Loisirs">Sport&Loisirs</option>
			</select><br/><br/>
			<input type="submit" name="submit">
		    </form>
		    <?php
		
		}
		else if($_GET['article']=='delete')
		{
			echo "<br><br>";
			echo 'Voici les articles présents sur le marché: ';
			$database = "ece_amazon";
			$db_handle = mysqli_connect('localhost', 'root', '' );
			$db_found = mysqli_select_db($db_handle, $database );
			if($db_found)
			{
				$SQL2="SELECT * FROM item";
			    $result = mysqli_query($db_handle, $SQL2);
     			mysqli_close($db_handle);
			}
			echo "<br>";
    		
    		while ($db_field = mysqli_fetch_assoc($result))
    		{
    			echo "<br>";
                echo $db_field['Nom'];
                echo "<br>";
            
        	}
        	if(isset($_POST['submit']))
			{
				
				if($_POST['Nom'])
				{
					$Nom=$_POST['Nom'];
					$database = "ece_amazon";
					$db_handle = mysqli_connect('localhost', 'root', '' );
					$db_found = mysqli_select_db($db_handle, $database );
					if ($db_found) 
					{
						$SQL = "DELETE FROM item WHERE Nom='$Nom'";
     					$result = mysqli_query($db_handle, $SQL);
     					mysqli_close($db_handle);

					}
					else 
					{
    					echo "Database NOT Found ";
					}
				}
		
			}
			?>
			<body style="background:#A9F5E1;"></body>
			<form align="center" action="" method="POST">
			<h3><b><u>Entrez l'item que vous voulez supprimer</u></b></h3>
			<h3><u>Nom:</u></h3><input placeholder="Entrez un Nom"type="text" name="Nom"/>
			<input type="submit" name="submit">
		    </form>
		    <?php
        }		

	}
}
else
{
	header('Location:index1.php');
}

require_once("footer.php");
?>
