<?php
require_once("header.php");
?>
<form align="center" action="" method="POST">
<h1><font color="red"><u><big>CHOIX DE LA COULEUR DU FOND D'ECRAN</big></u></font></h1>
<h2><u>BLEU :</u></h2>
<input type="submit" name="Bleu"/><br/><br/>
<h2><u>ROUGE :</u></h2>
<input type="submit" name="Rouge"/><br/><br/>
<h2><u>VERT :</u></h2>
<input type="submit" name="Vert"/><br/><br/>
<h2><u>JAUNE :</u></h2>
<input type="submit" name="Jaune"/><br/><br/>
</form>

<?php

if(isset($_POST['Bleu']))
{
	header('Location: vendre1.php');
}

if(isset($_POST['Rouge']))
{
	header('Location: vendre2.php');
}

if(isset($_POST['Vert']))
{
	header('Location: vendre3.php');
}

if(isset($_POST['Jaune']))
{
	header('Location: vendre4.php');
}

?>

<?php
require_once("footer.php");
?>