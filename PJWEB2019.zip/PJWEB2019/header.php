<!DOCTYPE html>
<html>
<head>
 <title>ECE.Amazon</title>
 <meta charset="utf-8"/>
</head>
<body>
	<h1 class="logo"> <img src="ece.png" alt="ECE.Amazon" width="342" height="80"/></h1>
	<div id="menu">
	    <li><a href="index1.php">Home</a></li>
	    <li><a href="Categories.php">Categories</a></li>
	    <li><a href="Ventesflash.php">Ventes Flash</a></li>
	    <li><a href="Vendre.php">Vendre</a></li>
	    <li><a href="Votrecompte.php">Votre Compte</a></li>
	    <li><a href="Panier.php">Panier</a></li>
	    <li><a href="Admin.php">Admin</a></li>
	</div>
</body>
</html>