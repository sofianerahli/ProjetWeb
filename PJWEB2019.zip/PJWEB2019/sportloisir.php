<?php
require_once("header.php");
$database = "ece_amazon";
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database );
	if($db_found)
	{
		$SQL="SELECT * FROM item WHERE Categorie='Sport&Loisirs'";
	    $result = mysqli_query($db_handle, $SQL);
		mysqli_close($db_handle);
	}
	echo "<br>";
	while ($db_field = mysqli_fetch_assoc($result))
	{
		?>
		<h2><?php echo $db_field['Nom'];?></h2><br/>
		<h5><?php echo $db_field['Description'];?></h5><br/>
		<h2><?php echo $db_field['Prix'];?> Euros</h2><br/>
		<br/><br/>
		<?php
	}
require_once("footer.php");
?>