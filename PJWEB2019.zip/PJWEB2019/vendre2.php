<?php
session_start();
require_once("header.php");
?>
<h1 align="center"><u><big>Bienvenue <?php echo $_SESSION['username'];?></big></u></h1>
<h2 align="right"><I><?php echo $_SESSION['username'];?></I></font> </h2>
<p align="right"><a href="?fond"><u>Choix du fond d'ecran</u></a></p>
<p align="right"><a href="?logout"><u>Déconnexion</u></a></p>
<p align="center"><a href="?article=add">Ajouter un item</a></p>
<body style="background:#FE2E2E;"></body>

<?php
if (isset ($_GET['logout'])){ 
	session_destroy(); 
	header('Location: index1.php');
}
if (isset ($_GET['fond'])){ 
	header('Location: choixfond.php');
}
?>
<?php
if(isset($_GET['article']))
	{
		if($_GET['article']=='add')
		{
			if(isset($_POST['submit']))
			{
				
				if(($_POST['Nom'])&&($_POST['Description'])&&($_POST['Prix'])&&($_POST['Categorie']))
				{
					$Nom=$_POST['Nom'];
					$Description=$_POST['Description'];
					$Prix=$_POST['Prix'];
					$Categorie=$_POST['Categorie'];
					$img=$_FILES['img']['name'];
					$img2=$_FILES['img']['name2'];

					if(!empty($img2))
					{
						$nom_image= explode('.',$img);
						$extension_image= end($nom_image);

						if(in_array(strtolower($extension_image),array('jpg','png','jpeg'))==false)
						{
							echo 'Extension non valide';
						}
						else
						{
							$image_size= getimagesize($img2);
							if($image_size['mime']=='image/png')
							{
								$source_image=imagecreatefrompng($img2);
							}
							else
							{
								$source_image= false;
								echo'Image non valide';
							}
						}



					}
					else
					{
						echo 'Veuillez rentrer une image';

					}


					$database = "ece_amazon";
					$db_handle = mysqli_connect('localhost', 'root', '' );
					$db_found = mysqli_select_db($db_handle, $database );
					if ($db_found) 
					{
						$SQL = "INSERT INTO item( Nom, Description, Prix, Categorie)  VALUES ('$Nom', '$Description', '$Prix', '$Categorie')";
     					$result = mysqli_query($db_handle, $SQL);
     					mysqli_close($db_handle);
    					echo "Vous avez ajouter un item au marché";
					}
					else 
					{
    					echo "Database NOT Found ";
					}
				}
				else
				{
					echo "Champs vides: Veuillez remplir";
				}	
			}
		?>
			<h3>Remplir les champs pour ajouter votre item<h3>
			<form align="center" action="" method="POST" enctype="multipart/form-data">
			<h3><u>Nom :</u></h3><input placeholder="Entrez votre nom" type="text" name="Nom"/>
			<h3><u>Description :</u></h3><textarea placeholder="Entrez votre description" name="Description"></textarea> 
			<h3><u>Prix :</u></h3><input placeholder="Entrez votre prix" type="text" name="Prix"/>
			<h3><u>Image :</u></h3><input type="file" name="img"/>
			<h3><u>Categorie :</u></h3>
			<select name="Categorie">
				<option value="Livres">Livres</option>
				<option value="Musique">Musique</option>
				<option value="Vêtemets">Vêtements</option>
				<option value="Sport&Loisirs">Sport&Loisirs</option>
			</select><br/><br/>
			<input type="submit" name="submit">
		    </form>
			</div> 
		<?php
		}
	}

require_once("footer.php");
?>