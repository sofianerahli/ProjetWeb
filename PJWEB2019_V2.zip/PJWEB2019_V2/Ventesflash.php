<!DOCTYPE html>
<html>
<head>
 <title>Ventes Flash</title>
 <meta charset="utf-8"/>
 <link href="prime.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h1>VENTES FLASH</h1>
	<div id="nav">
		<li><a href="index1.php">Home</a></li>
	</div>
</body>
</html>