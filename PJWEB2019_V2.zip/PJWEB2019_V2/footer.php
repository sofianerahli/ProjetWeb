<div class="footer-copyright text-center">&copy; 2019 Copyright | Droit
d'auteur: webDynamique.ece.fr</div>