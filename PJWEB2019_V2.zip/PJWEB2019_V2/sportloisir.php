<?php
require_once("header.php");
?>
<h1 align="center"><big>Sport & Loisir</big></h1>
<?php
$database = "ece_amazon";
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database );
	if($db_found)
	{
		$SQL="SELECT * FROM item WHERE Categorie='Sport&Loisirs'";
	    $result = mysqli_query($db_handle, $SQL);
		mysqli_close($db_handle);
	}
	echo "<br>";
	while ($db_field = mysqli_fetch_assoc($result))
	{
		echo '<br>';
		?>
		<body style="background:#A9F5E1;"></body>
<div style="background:white;width:30% ; padding: 0.5%;
    margin-left: auto;
    margin-right: auto;
    border: 1px solid #f1f1f1;
    background: #fff;
    box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);box-sizing: border-box;">
		<h2><?php echo $db_field['Nom'];?></h2><br/>
		<h5><?php echo $db_field['Description'];?></h5><br/>
		<h2><?php echo $db_field['Prix'];?> Euros</h2><br/>
		<br/><br/>
		<input type="button" value="Ajouter au panier" name="Panier">
	</div>
		<?php
	}
require_once("footer.php");
?>