
<h1><u><big>Bienvenue</big></u></h1>
<!DOCTYPE html>
<html>
<head>
 <title>Categories</title>
 <meta charset="utf-8"/>
 <link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h1>CATEGORIES</h1>
	<div id="nav">
		<li><a href="index1.php">Home</a></li>
	    <li><a href="livre.php">Livre</a></li>
	    <li><a href="musique.php">Musique</a></li>
	    <li><a href="vetements.php">Vetements</a></li>
	    <li><a href="sportloisir.php">Sport et Loisir</a></li>
	</div>
</body>
</html>
