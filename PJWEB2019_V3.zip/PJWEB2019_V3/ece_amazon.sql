-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 05 mai 2019 à 03:11
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ece_amazon`
--

-- --------------------------------------------------------

--
-- Structure de la table `acheteur`
--

DROP TABLE IF EXISTS `acheteur`;
CREATE TABLE IF NOT EXISTS `acheteur` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) NOT NULL,
  `Mdp` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `acheteur`
--

INSERT INTO `acheteur` (`Id`, `Email`, `Mdp`) VALUES
(1, 'ddf@ho.com', 'mmm'),
(2, 'afff@kf.fr', '12ddd');

-- --------------------------------------------------------

--
-- Structure de la table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Prix` int(11) NOT NULL,
  `Categorie` varchar(20) NOT NULL,
  `Photo` varchar(255) NOT NULL,
  `Stock` int(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `item`
--

INSERT INTO `item` (`Id`, `Nom`, `Description`, `Prix`, `Categorie`, `Photo`, `Stock`) VALUES
(10, 'a', 'aa', 10, '', '', 0),
(11, 'jhk', 'tf', 50, 'Livres', '', 0),
(12, 'jh', 'a', 10, 'Musique', '', 0),
(21, 'iuiu', 'khjphj', 10, 'Livres', '', 0),
(20, 'jhl', 'nnn', 10, 'Sport&Loisirs', '', 0),
(19, 'jhl', 'nnn', 10, 'Sport&Loisirs', '', 0),
(25, 'o', 'jioo', 10, 'Livres', '', 0),
(26, 'o', 'jioo', 10, 'Livres', '', 0),
(37, 'xxs', 'd', 10, 'Musique', '', 0),
(36, 'a', 'kl', 10, 'Musique', '', 0),
(46, 'dd', 'dd', 1, 'Vetements', '', 0),
(47, 'aa', 'mmm', 20, 'Livres', '\"C:wamp64wwwsoleil.png\"', 0),
(51, 'Soleil', 'SO', 25, 'Livres', 'soleil.png', 0),
(49, 'rez', 'dd', 40, 'Livres', 'C:wamp64wwwsoleil.png', 0),
(50, 'aa', '55', 200, 'Livres', 'soleil.png', 0),
(52, 'test', '55', 20, 'Livres', 'soleil.png', 25);

-- --------------------------------------------------------

--
-- Structure de la table `vendeur`
--

DROP TABLE IF EXISTS `vendeur`;
CREATE TABLE IF NOT EXISTS `vendeur` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `vendeur`
--

INSERT INTO `vendeur` (`Id`, `email`, `pseudo`, `nom`) VALUES
(3, 'sofiane@hotmail.com', 'soso', 'so'),
(15, 'kj@hotmail.com', 'kjd', ''),
(13, 'kj@hotmail.com', 'dd', 'so');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
