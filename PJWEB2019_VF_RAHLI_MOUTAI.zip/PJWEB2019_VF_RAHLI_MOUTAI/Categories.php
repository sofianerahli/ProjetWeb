<?php
require_once("header.php");
?>
<h1 align="center"><u><big>Bienvenue dans les Catégories</big></u></h1>
<body style="background-image: url('categorie.png'); background-size:cover;  "></body>
<form align="center" action="" method="POST">
<!DOCTYPE html>
<html>
<head>
 <title>Categories</title>
 <meta charset="utf-8"/>
 <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	    <a href="livre.php"><img src="livres.jpg" alt="livres" width="380" height="280" align="center" class="livres" /></a>
	    <a href="musique.php"><img src="musique.jpg" alt="Musique" width="380" height="280" align="center" class="musique"  /></a>
	    <a href="vetements.php"><img src="vêtements.jpg" alt="vêtements" width="380" height="280" align="center" class="vetements" /></a>
	    <a href="sportloisir.php"><img src="sportsloisirs.png" alt="sportsloisirs" width="380" height="280" align="center" class="sport" /></a>
</body>
</html><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
require_once("footer.php");
?>