<div class="footer-copyright" align="center">&copy; 2019 Copyright | Droit
d'auteur: webDynamique.ece.fr</div>