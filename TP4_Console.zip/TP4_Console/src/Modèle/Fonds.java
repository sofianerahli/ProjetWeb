
package Modèle;

/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class Fonds implements Comparable<Fonds>
{
    private double amount; //Montant du fond
    
    /**
     * Constructeur Fonds
     */
    public Fonds()
    {
        amount=0.0;
    }
    
    public Fonds(double par_amount)
    {
        this.amount=par_amount;
    }
    
    
    //Getter 
    public double getAmount() 
    {
        return amount;
    }
    
   
    /**
    * Méthode qui compare l'égalité entre 2 valeurs
     * @param E
     * @return 
    */
    public boolean equals(Fonds E)
    {
        if(this.getAmount()==E.getAmount())
        {
          return true; //Les 2 valeurs sont égales
        }
        else
        {
            return false; //Les 2 valeurs ne sont pas égales   
        }
    }
    
    /**
    * Méthode qui compare des valeurs
     * @param C
     * @return 
    */
    @Override
    public int compareTo(Fonds C) 
    {
        if(this.getAmount()>C.getAmount())
        {
            return 1;
        }
        
        if(equals(C)==true)
        {
            return 0;
        }
        
        else
        {
            return -1;
        }
        
    }
    
}
