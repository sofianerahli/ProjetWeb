
package Modèle;

/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class FondsInexistant extends Exception{
    
    public String getMes()
    {
        String s = "Fonds Inexistant";
        return s;
    }
}
