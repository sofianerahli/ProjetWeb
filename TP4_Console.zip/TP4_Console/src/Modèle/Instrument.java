
package Modèle;

import java.util.ArrayList;
import java.util.Collections;

/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli,moutai
 */
public class Instrument {
    
    private ArrayList<Fonds> tab; //Instrument 
      
    /**
    * Constructeur Instrument
    */
    public Instrument()
    {
        tab = new ArrayList<Fonds>(); // ArrayList de Fonds
    }
    
    public Instrument(ArrayList<Fonds> newFonds)
    {
        tab = newFonds;
    }
    
    /**
    * Methode qui permet d'ajouter un fond 
    * @param amount1
    */
    public void addFonds(Fonds amount1)
    {
        tab.add(amount1);
    }
    
    /**
    * Getter
    * @return 
    */
    public ArrayList getTab()
    {
        return tab;
    }
    
    /**
    * Méthode qui trie 
    */
    public void Trie()
    {
        Collections.sort(tab);  
    }
}
