
package Modèle;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class Portefeuille 
{
    private HashMap<String, Fonds> mapFonds;
    private HashMap<String, Instrument> mapInstru;
    
    /**
    *Constructeur sans par
    */
    public Portefeuille()
    {
        mapFonds= new HashMap<String,Fonds>();
        mapInstru= new HashMap<String,Instrument>();
    }
    
    /**
    *Constructeur avec par
     * @param par_mapFonds
     * @param par_mapInstru
    */
    public Portefeuille(HashMap<String, Fonds> par_mapFonds,HashMap<String, Instrument> par_mapInstru)
    {
        mapFonds= new HashMap<String,Fonds>();
        mapInstru= new HashMap<String,Instrument>();
        
        this.mapFonds= par_mapFonds;
        this.mapInstru= par_mapInstru;
    }
    
    /**
    *Méthode qui cherche un fond grace à sa clé
     * @param keyFonds
     * @return 
     * @throws Modèle.FondsInexistant
    */
    public double searchFonds(String keyFonds) throws FondsInexistant 
    {
        Fonds F= mapFonds.get(keyFonds);
        
        if (F!=null)
        {
            return F.getAmount();
        }   
        else
        {
            throw new FondsInexistant(); //Fonds inexistant
        }
    }
    
    /**
    *Méthode qui cherche un instrument grace à sa clé
     * @param keyInstrument
     * @return 
     * @throws Modèle.InstrumentInexistant
    */
    public ArrayList searchInstru(String keyInstrument) throws InstrumentInexistant
    {
        Instrument I= mapInstru.get(keyInstrument);
        ArrayList<Fonds> ListeFonds= new ArrayList<Fonds>();
    
              
        if (I!=null)
        {
            ListeFonds=I.getTab();
            return ListeFonds;
        }   
        else
        {
            throw new InstrumentInexistant(); //Fonds inexistant
        }
    }
    
    /**
    *Méthode qui ajoute un fond à la hashmap des fonds
     * @param keyFonds
     * @param amount
     * @throws Modèle.FondsExistant
    */
    public void addNewFonds(String keyFonds,double amount)throws FondsExistant
    {   
        
        Fonds F=mapFonds.get(keyFonds);
        
        if(F!=null)
        {
            throw new FondsExistant();
        }
        else
        {
            F= new Fonds(amount);
            mapFonds.put(keyFonds,F);
            System.out.println("Vous avez ajouté un Fond");
        }		
    }
    
    /**
    *Méthode qui ajoute un instrument à la hashmap des instruments
     * @param keyInstru
     * @param I
    */
    public void addnewInstrument(String keyInstru,Instrument I) 
    {
        mapInstru.put(keyInstru,I);
	System.out.println("Instrument ajouté");
    }
    
    /**
    *Méthode qui supprime un fond de la hashmap
     * @param key
     * @throws Modèle.FondsInexistant
    */
    public void deleteFonds(String key) throws FondsInexistant
    {
        try 
        {
            searchFonds(key);
            mapFonds.remove(key);
            System.out.println("Fond supprimé");
        } 
        catch (FondsInexistant e) 
        {
            System.out.println("Le fond n'existe pas");
        }
		
    }
    
    /**
    *Méthode qui supprime un instrument de la hashmap
     * @param key
    */
    public void deleteInstrument(String key)
    {
        try 
        {
            searchInstru(key);
            searchInstru(key).clear();
            mapInstru.remove(key);
            System.out.println("Instrument supprimé");
        } 
        catch (InstrumentInexistant e) 
        {
            System.out.println("L'intrument n'existe pas");
        }
    }
    
    
    //setters et getters
    public HashMap<String,Fonds> getFondMap(){
        return mapFonds;
    }
    
    public HashMap<String,Instrument> getInstrumentMap(){
        return mapInstru;
    }
    
    public void setFondMap(HashMap<String,Fonds> newFondsMap){
        mapFonds.putAll(newFondsMap);
    }
    
     public void setInstrumentMap(HashMap<String,Instrument> newInstrumentMap){
        mapInstru.putAll(newInstrumentMap);
    }
    
	
    
    
}
