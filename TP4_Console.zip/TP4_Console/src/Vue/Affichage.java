/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modèle.Fonds;
import Modèle.Instrument;
import Modèle.Portefeuille;
import java.util.Map;

/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class Affichage {
    
    Portefeuille P;
    /**
    *Constructeur Affichage qui prend un portefeuille en par
     * @param par_p
    */
    public Affichage(Portefeuille par_p)
    {
        this.P=par_p;
    }
    
    /**
    *Methode qui affiche un instrument(sa clé, son nombre de fonds et sa somme des montants du fond
     * @param p
    */
    public void A_Instru(Portefeuille p)
    {
        for(Map.Entry map : p.getInstrumentMap().entrySet()) 
        {		
            double total=0;

            for(int i=0 ; i<((Instrument)map.getValue()).getTab().size() ; i++)
            {
                total=total+((Fonds)((Instrument) map.getValue()).getTab().get(i)).getAmount();
            }

            System.out.println("Clé de l'intrument : "+map.getKey());
            System.out.println("Nombre total de fonds : "+((Instrument) map.getValue()).getTab().size());
            System.out.println("Somme total des montants : "+total); 

        }
    }
    
}
