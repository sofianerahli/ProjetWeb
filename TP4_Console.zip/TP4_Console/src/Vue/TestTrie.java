/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;
import Modèle.*;
import java.util.Scanner;
/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class TestTrie 
{ 
    /**
    *Constructeur TestTrie qui trie les fonds selon leur montant
     * @param I
    */
    public TestTrie(Instrument I)
    {
        Scanner sc= new Scanner(System.in);
                
        System.out.println("Rentrer le nombre de fonds que vous voulez ajouter : ");
        int nombre=sc.nextInt();
  
        System.out.println("Rentrer la valeur des fonds : ");
        for(int a = 0;a<nombre;a++)
        {
            System.out.println("Valeur du fond"+a+": ");
            double val=sc.nextDouble();
            Fonds F=new Fonds(val);
            I.addFonds(F);
        }
        
        System.out.println("Liste des fonds : ");
        for(int i = 0;i<nombre;i++)
        {
        System.out.println(((Fonds) I.getTab().get(i)).getAmount());
        }
 
        I.Trie();
        System.out.println("Liste des fonds triés : ");
        for(int j = 0;j<nombre;j++)
        {
        System.out.println(((Fonds) I.getTab().get(j)).getAmount());
        }
    }
}
