/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

import Modèle.*;
import Vue.*;
import java.util.Scanner;
/**
 *sources: openclassroom, TPs de MME PALASI, Cours de MR SEGADO
 * @author rahli, moutai
 */
public class Main 
{
    public static void main(String[] args) throws FondsInexistant, FondsExistant, InstrumentInexistant
    {
        
        Portefeuille p = new Portefeuille(); //Nouveau portefeuille
        Instrument I= new Instrument(); //Nouvel instrument
        
        //new TestTrie(I);  // METHODE POUR LE TRIE
        
        
        /*******TEST FOND******/
 
        Scanner sc = new Scanner(System.in);
     
        //Clé et Montant du Fond
        System.out.println("|||||| AJOUT D'UN FOND ||||||");
        System.out.println();
     
        System.out.println("Tapez le nombre de fonds que vous voulez ajouter :");
        int nb= sc.nextInt(); //Nb de fonds à ajouter
        
        for(int a = 0;a<nb;a++)
        {
            System.out.println("Entrer la clé du fond : ");
            String keyFonds = sc.next(); //Récupere la valeur de la clé tapé    
            
            System.out.println("Valeur du fond "+a+": ");
            double montant=sc.nextDouble(); //Recupere la valeur du montant du fond
            Fonds F=new Fonds(montant);
            I.addFonds(F); //Ajoute le fond à l'instrument
          
            //Question 1.5 pour l'ajout d'un fond dans le portefeuille
            try
            {
                p.searchFonds(keyFonds); //Recherche la clé dans le portefeuille 
                System.out.println("ce Fond existe déjà"); 
            }
            catch(FondsInexistant e)
            {
                System.out.println(e.getMes()); // Fond inexistant
                p.addNewFonds(keyFonds,montant); // Ajout du Fond à la Hashmap  

            } 
        }
        System.out.println();
       
        
        //Affiche les fonds présent dans le portefeuille 
        System.out.println("Voici les fonds présents dans le portefeuille : ");
        for(String i:p.getFondMap().keySet())
        {
            System.out.println("Clé du fond : "+i);
            System.out.println("Montant du Fond : "+p.searchFonds(i));
        }
        
        System.out.println();
        
        ////TEST SUPPRIMER UN FOND///
        System.out.println("Tapez le nombre de fonds que vous voulez supprimer :");
        int nbsupp= sc.nextInt(); //Recupere la valeur du nb de fonds à supp
        
        for(int c = 0;c<nbsupp;c++)
        {
        System.out.println("Rentrer la clé du fond que vous voulez supprimer : ");
        String keyFonds=sc.next(); //Clé à supp
        p.deleteFonds(keyFonds); 
        }
        
        System.out.println();
        //Affiche les fonds dans le portefeuille aprés suppression
        System.out.println("Voici les fonds présents aprés suppression dans le portefeuille : ");
        for(String i:p.getFondMap().keySet())
        {
            System.out.println("Clé du fond : "+i);
            System.out.println("Montant du Fond : "+p.searchFonds(i));
        }
        
          
        /*******TEST INSTRUMENT*****////
       
        Scanner toto = new Scanner(System.in);
        System.out.println();
        System.out.println("||||| AJOUT D'UN INSTRUMENT ||||||");
        
        System.out.print("Tapez le nombre d'instruments que vous voulez ajouter :");
        int nbaj= toto.nextInt(); //Nb d'instru à ajouter
        
        for(int d = 0;d<nbaj;d++)
        {
            System.out.println("Entrer la clé de l'intrument : ");
            String keyInstru = toto.next();
       
            //Question 1.6 pour l'ajout d'un instrument dans le portefeuille
            try
            {
                p.searchInstru(keyInstru); 
                System.out.println("Cet intrument existe déjà"); 
            }
            catch(InstrumentInexistant e)
            {
                System.out.println(e.getMes()); //Instrument inexisant
                
                p.addnewInstrument(keyInstru,I); //Ajout de l'instrument à la Hashmap
            }

        }
        
        Affichage a= new Affichage(p); //Création d'un nouvel affichage du portefeuille
        System.out.println();
        
        //Affiche les instruments dans le portefeuille mais n'affiche rien quand il n'y pas d'instrument 
        System.out.println("Voici les instruments présents dans le portefeuille : ");
        a.A_Instru(p);
        System.out.println();
        
        ////TEST SUPPRIMER UN Instrument///
        System.out.print("Tapez le nombre d'instruments que vous voulez supprimer :");
        int nbisupp= sc.nextInt();
        
        for(int c = 0;c<nbisupp;c++)
        {
        System.out.print("Rentrer la clé de l'instrument que vous voulez supprimer : ");
        String keyInstru=sc.next();
        p.deleteInstrument(keyInstru); 
        }
        
        System.out.println();
        System.out.println("Voici les instruments présents aprés suppression dans le portefeuille : ");
        a.A_Instru(p);  
        
    }
}
